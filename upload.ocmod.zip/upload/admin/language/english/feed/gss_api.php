<?php

// Heading
$_['heading_title'] = 'GSS API';

// Text
$_['text_feed'] = 'Feeds';
$_['text_success'] = 'Success: You have modified GSS API feed!';
$_['text_edit'] = 'Edit GSS API';

// Entry
$_['entry_status'] = 'Status';
$_['entry_key'] = 'Secret Key';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify GSS API feed!';
